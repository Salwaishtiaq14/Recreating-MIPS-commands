#include "emulator.h"
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

void usage() {
    printf("./emulator -i filename.asm\n");
    return;
}

int main(int argc, char **argv)
{

    char *filename = "simple_add.asm";
    
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-i") == 0 && i + 1 < argc) {
            filename = malloc(strlen(argv[i + 1]) + 1);
            strcpy(filename, argv[i + 1]);
            i++; // Skip the next argument since it's already processed
        } else if (strcmp(argv[i], "-h") == 0) {
            usage();
            return 0;
        } else {
            printf("Unknown option: %s\n", argv[i]);
        }
    }


	if (load_program(filename) < 0)
		return (-1);

	if (make_bytecode() < 0)
		return (-1);

	if (exec_bytecode() < 0)
		return (-1);

	return (0);
}
